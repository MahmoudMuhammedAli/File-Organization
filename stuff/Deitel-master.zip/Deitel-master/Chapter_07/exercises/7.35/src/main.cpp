#include <iostream>
#include "Poll.hpp"

int main(int argc, char const *argv[])
{
    Poll poll;
    poll.go();

    return 0;
}
