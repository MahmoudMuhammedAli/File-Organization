#include <iostream>

int main()
{
    for (unsigned int counter = 1; counter <= 10; ++counter)
    {
        std::cout << counter << " ";
    }

    std::cout << std::endl;

    return 0;
}