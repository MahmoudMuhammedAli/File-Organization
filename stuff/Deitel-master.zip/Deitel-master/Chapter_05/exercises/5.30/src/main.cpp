#include <iostream>
#include "Quiz.hpp"

int main()
{
    Quiz q1;
    q1.run();

    return 0;
}