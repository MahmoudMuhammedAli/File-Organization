#include <iostream>
#include "SalaryCalculator.hpp"
int main()
{
    SalaryCalculator sc;

    sc.inputSalaries();
    return 0;
}