#include "GradeBook.hpp"

int main()
{
    GradeBook myGradeBook("CS101 C++ Programming");
    myGradeBook.displayMessage();
    myGradeBook.determineClassAvarage();
    return 0;
}