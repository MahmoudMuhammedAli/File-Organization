#include <iostream>



int main(int argc, char const *argv[])
{
    int number{ 2 };

    while (true)
    {

        std::cout << number << std::endl;
        number *=2;
    }



    return 0;
}

