#include <iostream>
#include "Date.hpp"

int main()
{

    Date date1(12, 7, 1983);
    Date date2(23, 6, 1984);

    date1.displayDate();
    date2.displayDate();
    return 0;
}