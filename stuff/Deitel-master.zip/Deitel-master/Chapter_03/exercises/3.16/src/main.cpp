#include <iostream>
#include "HeartRates.hpp"

int main()
{
    HeartRates h1("Aylin", "Aydin",
                  22, 9, 1992);

    h1.displayInformation();

    return 0;
}