#include "GradeBook.hpp"

int main()
{
    GradeBook gradeBook1("This is a course", "The Instructor");

    gradeBook1.displayMessage();

    system("pause");
    return 0;
}
