#include "GuessTheNumber.hpp"

int main()
{
    GuessTheNumber gtn;

    gtn.run();

    return 0;
}
