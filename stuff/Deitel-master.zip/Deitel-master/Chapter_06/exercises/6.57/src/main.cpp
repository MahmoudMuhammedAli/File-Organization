#include <iostream>
#include "CAI.hpp"

int main()
{
    CAI cai;
    cai.run();

    return 0;
}
