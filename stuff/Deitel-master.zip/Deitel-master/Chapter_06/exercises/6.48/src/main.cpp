#include <iostream>
#include "Craps.hpp"

int main()
{
    Craps crap;
    crap.run();

    return 0;
}
