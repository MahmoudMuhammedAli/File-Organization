#include <iostream>

void zero(long *);

int add1AndSum(int *);

int main(int argc, char const *argv[])
{

    return 0;
}
int add1AndSum(int *oneTooSmall) {}
void zero(long *bigIntegers) {}