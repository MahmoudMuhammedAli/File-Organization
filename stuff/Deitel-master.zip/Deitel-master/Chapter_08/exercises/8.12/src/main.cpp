#include <iostream>
#include "TortoiseAndHare.hpp"

int main(int argc, char const *argv[])
{
    TortoiseAndHare th;
    th.go();

    return 0;
}
