#include <iostream>
#include <iomanip>
#include "Simpletron.hpp"

using namespace std;

const int SIZE = 100;
const int MAX_WORD = 9999;
const int MIN_WORD = -9999;
const long SENTINEL = -99999;

int main(int argc, char const *argv[])
{

    Simpletron s;
    s.run();

    return 0;
}
